import { RxDragHandleDots2 } from "react-icons/rx";

export default function AssignmentDragHandle() {
    return (
        <div className="d-flex flex-column">
            <RxDragHandleDots2 className="text-muted fs-4" />

        </div>
    );
}
